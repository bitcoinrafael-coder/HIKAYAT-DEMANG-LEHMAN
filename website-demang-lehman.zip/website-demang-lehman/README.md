# Website Ebook - Sang Panglima Tak Berkepala
Hikayat Demang Lehman - Disadur oleh Rafael Sukirno, CE.

## Cara Deploy ke GitHub Pages
1. Buat repository baru di GitHub, misal: demang-lehman-ebook
2. Upload semua file di folder ini (index.html + folder images)
   - Bisa drag & drop di github.com atau pakai git:
     ```
     git init
     git add .
     git commit -m "ebook demang lehman"
     git branch -M main
     git remote add origin https://github.com/USERNAME/demang-lehman-ebook.git
     git push -u origin main
     ```
3. Di GitHub, masuk Settings > Pages
4. Source: Deploy from branch, Branch: main, Folder: / (root)
5. Save. Tunggu 1-2 menit, website akan live di https://USERNAME.github.io/demang-lehman-ebook/

## Struktur File
- index.html = website utama (single file, no React, no build needed)
- images/ = cover + ilustrasi benteng, jukung, keris

Website sudah responsive: enak dibaca di HP dan laptop, ada daftar isi, progress bar, tombol font size.

Edisi Premium Bergambar - Benteng Belanda Martapura 1860.
